

<?php $__env->startSection('content'); ?>
        <div class="container rounded px-5 py-4 bg-white mb-5 form-container">
            <h3 class="pt-3 pb-5">
                Update user, <?php echo e($user->name); ?>

            </h3>
            
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group d-flex flex-column pb-5 position-relative aos-init aos-animate" data-aos="zoom-in-up" data-aos-duration="1000">
                <label class="contact-label fs-5 fw-bold" for="name">Name</label>
                <input type="text" class="contact-input" id="name" name="name" value="<?php echo e($user->name); ?>" required>
            </div>
            <div class="form-group d-flex flex-column pb-5 position-relative aos-init aos-animate" data-aos="zoom-in-up" data-aos-duration="1000">
                <label class="contact-label fs-5 fw-bold" for="email">Email</label>
                <input type="email" class="contact-input" id="email" name="email" value="<?php echo e($user->email); ?>" required>
            </div>
            <div class="form-group d-flex flex-column pb-5 position-relative aos-init aos-animate" data-aos="zoom-in-up" data-aos-duration="1000">
                <label class="contact-label fs-5 fw-bold" for="number">Phone Number</label>
                <input type="tel" class="contact-input" id="number" name="number" value="<?php echo e($user->phone); ?>" required>
            </div>
            <div class="form-group d-flex flex-column pb-5 position-relative aos-init aos-animate" data-aos="zoom-in-up" data-aos-duration="1000">
                <label class="contact-label fs-5 fw-bold" for="cnic">CNIC</label>
                <input type="text" class="contact-input" id="cnic" name="cnic" pattern="[0-9]{13}" value="<?php echo e($user->cnic); ?>" required>
            </div>
            <div class="form-group d-flex flex-column pb-5 position-relative aos-init aos-animate" data-aos="zoom-in-up" data-aos-duration="1000">
                <label class="contact-label fs-5 fw-bold" for="password">Password</label>
                <input type="password" class="contact-input" id="password" name="password" value="<?php echo e($user->password); ?>" required>
            </div>
            <div class="d-flex justify-content-end">
                <input class="btn update-btn rounded-pill fw-bold fs-5" type="submit" name="submit" id="submit" value="Update">
            </div>
        </form>
        
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB-Projects\projectweb_ajax\projectweb\resources\views//admin/users/user.blade.php ENDPATH**/ ?>