

<?php $__env->startSection('content'); ?>
        <div class="container px-5">
            
        <div class="row pt-5">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Users</h5>
                        <p class="card-text">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">User ID</th>
                                        <th scope="col">Tax Year</th>
                                        <th scope="col">Nationality</th>
                                    </tr>
                                </thead>
                                <tbody id="myTable">
                                    <?php $__currentLoopData = $formlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($form->id); ?></th>
                                            <td><?php echo e($form->user_id); ?></td>
                                            <td><?php echo e($form->tax_year); ?></td>
                                            <td><?php echo e($form->nationality); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\92310\Downloads\projectweb_ajax\projectweb\resources\views//admin/formsubmitted.blade.php ENDPATH**/ ?>