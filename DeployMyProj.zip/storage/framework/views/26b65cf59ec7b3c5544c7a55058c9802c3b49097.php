<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        EasyTax | Home
    </title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Font-Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css" rel="stylesheet">
    <!-- External Stylesheet -->
    <link rel="stylesheet" href="/app.css">
</head>

<body>
    <header>
        <!-- As a heading -->
        <nav class="navbar bg-transparent position-absolute p-0">
            <div class="container-fluid pt-3 d-flex justify-content-between">
                <div class="logo-content ps-2 ps-md-4 ps-lg-5 pt-4">
                    <a class="fw-bold fs-1 text-white text-decoration-none logo-name" href="#">
                        E-Tax
                    </a>
                </div>
                <div class="nav-toggler">
                    <button class="navbar-toggler m-3 mt-md-0 me-md-0 fixed-top ms-auto text-white" id="menu-btn"
                        type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop"
                        aria-controls="offcanvasTop">
                        <i class="fa-solid fa-ellipsis-vertical fa-sm menu-icon"></i>
                        <i class="fa-solid fa-ellipsis-vertical fa-sm menu-icon"></i>
                        <i class="fa-solid fa-ellipsis-vertical fa-sm"></i>
                        <span class="d-none d-md-inline navbar-brand mb-0 h1">Menu</span>
                    </button>
                </div> 
            </div>
        </nav>
        <div class="offcanvas menu-body offcanvas-top h-100 text-white" tabindex="-1" id="offcanvasTop"
            aria-labelledby="offcanvasTopLabel">
            <div class="offcanvas-header">
                <div class="logo-content ps-2 ps-md-4 ps-lg-5 pt-4">
                    <a class="fw-bold fs-1 text-white text-decoration-none logo-name ms-5 ps-5" href="#">
                        E-Tax
                    </a>
                </div>
                <button type="button"
                    class="arrow-btn text-white bg-transparent border-secondary border rounded-circle mt-4 me-5"
                    data-bs-dismiss="offcanvas" aria-label="Close">
                    <i class="fa-solid fa-close fa-xs"></i>
                </button>
            </div>
            <div class="offcanvas-body d-flex justify-content-center">
                <div class="row container bg-transparent">
                    <div class="col-md-6 p-4">
                        <ul class="fs-2 lh-lg">
                            <li class="nav-option">
                                <a href="./whoarewe.html">
                                    Who are we?
                                </a>
                            </li>
                            <li class="nav-option">
                                <a href="./services.html">
                                    What can we do for you?
                                </a>
                            </li>
                            <li class="nav-option">
                                <a href="./taxtools.html">
                                    Tax Tools
                                </a>
                            </li>
                            <li class="nav-option">
                                <a href=./signup.html">
                                    Register Now
                                </a>
                            </li>
                            <li class="nav-option">
                                <a class="login text-white" href="./login.html">
                                    LogIn
                                </a>
                            </li>
                            <li class="nav-option">
                                <a href="./privacypolicy.html">
                                    Privacy Policy
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 d-flex flex-column justify-content-start align-items-center pt-5">
                        <div class="fs-3 lh-sm mb-5">
                            Register NTN & <br>File Tax Return <br>Easily with Befiler
                        </div>
                        <div class="btn btn-lg contact-btn text-white rounded-pill mt-5">
                            <a href="contact.html">
                                Contact Us
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <main>
        <section class="banner" id="banner">
            <div class="position-absolute w-100 banner-cover h-100 d-flex flex-column justify-content-between">
                <div class="imagem-1">
                    <img class="banner-svg1" src="svg/bannerimg1.svg" frameborder="0"></img>
                </div>
                <div class="container py-3 px-4 w-75 d-flex justify-content-between flex-column  flex-md-row">
                    <div>
                        <h1 class="display-5 text-white fw-bold pb-3" id="slider-heading">
                            Pakistan's #1 <br>
                            Tax Solution
                        </h1>
                        <p class="text-white fs-3 fw-light lh-sm d-none d-md-inline" id="slider-subheading">
                            We are the leading tax <br>
                            solution provider in Pakistan.
                        </p>
                        <div class="p-3">
                            <button
                                class="arrow-btn  btn hoverarrowrightbutton text-white border border-3 arrow-icon bg-transparent rounded-circle">
                                <i class="fa-solid fa-angle-right fa-xs"></i>
                            </button>
                        </div>
                    </div>
                    <div class="slider-icons text-white d-flex flex-row flex-md-column justify-content-between pt-3">
                        <i class="slider-icon fa-solid fa-circle fa-2xs"></i>
                        <i class="slider-icon fa-solid fa-circle-notch fa-2xs"></i>
                        <i class="slider-icon fa-solid fa-circle-notch fa-2xs"></i>
                    </div>
                </div>
                <div class="imagem-2 ms-auto">
                    <img class="banner-svg2" src="svg/bannerimg2.svg" alt="">
                </div>
            </div>
        </section>
        <section class="banner-second d-flex justify-content-center align-items-center mb-5">
            <div class="row container py-3 px-4 w-75 d-flex justify-content-between flex-column flex-md-row">
                <div class="col-md-6">
                    <h1 class="display-5 text-white fw-bold pb-3" id="slider-heading">
                        The Quickest and Simplest Way to get <br>NTN and <br>File Your Taxes
                    </h1>
                </div>
                <div class="col-md-7 mt-5">
                    <div>
                        <p class="high-z-index text-white fs-3 fw-dark lh-sm d-md-inline" id="slider-subheading">
                            What's Included? <br> Complete Support by Our Tax Expert support in Filing Your Tax Return.
                            <br> And we've made the process extremely simple you're going to love it
                        </p>
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-3 d-md-inline">
                                <div
                                    class="btn btn-lg hoverbutton2 contact-btn2 border border-secondary text-white rounded-pill mt-5">
                                    <p>
                                        People
                                    </p> 
                                </div>
                            </div>
                            <div class=" col-12 col-sm-12 col-md-12 offset-md-1 col-lg-3 d-md-inline">
                                <div
                                    class="btn hoverbutton3 btn-lg contact-btn2  border border-secondary text-white rounded-pill mt-5">
                                    <p>
                                        Our Focus
                                    </p>
                                </div>
                            </div>
                            <div class="offset-3 col-12 col-md-2 d-md-inline mt-5">
                                <button class=" btn second-bannerarrow text-white rounded-circle  ">
                                    <i class=" fa-solid fa-angle-right fa-xs"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="banner-third">
            <div class="container py-3 px-4 w-75 d-flex justify-content-between flex-column">
                <div class="mt-5">
                    <h5 class="text-secondary fw-bold">
                         Tax Savings
                    </h5>
                    <h1 class="text-white fw-bold pb-3" id="slider-heading">
                        Get maximum tax savings like <br>claiming tax credits
                    </h1>   
                </div>
                <div class="mt-3">
                    <h5 class="text-secondary fw-bold">
                        -- Avoid Penalties
                    </h5>
                    <h1 class="text-white fw-bold pb-3" id="slider-heading">
                        Be a responsible citizen and <br>avoid penalties
                    </h1>   
                </div>
                <div class="mt-3">
                    <h5 class="text-secondary fw-bold">
                        -- Compliance Check
                    </h5>
                    <h1 class="text-white fw-bold pb-3" id="slider-heading">
                        Many government-related <br>organizations and banks now
                    </h1>   
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="container mt-5">
            <div class="row">
                <div class="offset-1 col-11 col-md-7">
                    <ul class="foot-items lh-lg fs-4 mt-5">
                        <div class="row">
                            <li class="col-md-4 foot-option">
                                <a href="#">
                                    Who are we?
                                </a>
                            </li>
                            <li class="col-md-4 foot-option">
                                <a href="#">
                                    What can we do for you?
                                </a>
                            </li>
                            <li class="offset-md-1 col-md-2 foot-option">
                                <a href="#">
                                    Tax Tools
                                </a>
                            </li>
                        </div>
                        <div class=" row">
                            <li class="col-md-4 foot-option">
                                <a href="#">
                                    Register Now
                                </a>
                            </li>
                            <li class="col-md-4 foot-option">
                                <a href="#">
                                    Privacy Policy
                                </a>
                            </li>
                        </div>
                    </ul>
                </div>
                <div class="offset-1 col-11 offset-md-0 col-md-4">
                    <div class="btn btn-lg contact-btn text-white rounded-pill mt-5">
                        <a href="/contact.html">
                            Contact Us
                        </a>
                    </div>
                    <a href="#top">
                        <button
                            class="arrow-btn btn mt-5 ms-4 text-white border border-3 arrow-icon bg-transparent rounded-circle">
                            <i class="fa-solid fa-angle-up fa-xs"></i>
                        </button>
                    </a>
                </div>
            </div>
            <div class="container d-flex justify-content-center">
                <span class="copy-right text-secondary bg-transparent m-5 fs-5">© Copyright 2022 E-tax.com - All
                    rights reserved. -
                    Privacy policy</span>
            </div>
        </div>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script>
        setInterval(changeSlide, 5000)
        var colors = ["#011FFF", "#7729FB", "#21A7FC"]
        var headings = ["Pakistan's #1 <br>Tax Solution", "Online Tax <br>Filing Portal", "Already Using <br>Our Services"]
        var subheadings = ["We are the leading tax <br>solution provider in Pakistan.", "We provide online tax filing <br>services to all tax departments.", "Already using our services? <br>Click here to login."]
        var index = 2;
        function changeSlide() {
            var banner = document.getElementById('banner');
            banner.style.backgroundImage = "url('img/banner-" + index + ".jpg')";
            document.getElementById("menu-btn").style.backgroundColor = colors[index - 1];
            document.getElementById("slider-heading").innerHTML = headings[index - 1];
            document.getElementById("slider-subheading").innerHTML = subheadings[index - 1];
            var sliderIcons = document.getElementsByClassName("slider-icons");
            for (var i = 0; i < 3; i++) {
                if (i == (index - 1)) {
                    if (!sliderIcons[0].children[i].classList.contains("fa-circle-notch")) {
                        sliderIcons[0].children[i].classList.remove("fa-circle-notch");
                        sliderIcons[0].children[i].classList.add("fa-circle");
                    }
                }
                else {
                    sliderIcons[0].children[i].classList.remove("fa-circle");
                    sliderIcons[0].children[i].classList.add("fa-circle-notch");
                }
            }
            var icon_classes = document.getElementsByClassName("slider-icons")[0].children[index - 1].classList;
            if (icon_classes.contains("fa-circle-notch")) {
                document.getElementsByClassName("slider-icons")[0].children[index - 1].classList.remove("fa-circle-notch");
                document.getElementsByClassName("slider-icons")[0].children[index - 1].classList.add("fa-circle");
            }
            else {
                document.getElementsByClassName("slider-icons")[0].children[index - 1].classList.remove("fa-circle");
                document.getElementsByClassName("slider-icons")[0].children[index - 1].classList.add("fa-circle-notch");
            }
            index = index == 3 ? 1 : index + 1;
            console.log(document.getElementsByClassName("slider-icons")[0].children[index - 1].classList[2])
        }
    </script>
</body>

</html><?php /**PATH D:\xampp\htdocs\LARAVEL\projectweb\resources\views/welcome.blade.php ENDPATH**/ ?>